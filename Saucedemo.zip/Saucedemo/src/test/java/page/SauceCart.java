package page;

import base.BaseSauce;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SauceCart extends BaseSauce {
    @FindBy (className = "shopping_cart_badge")
    WebElement shoppingCart;

    public SauceCart () {
        PageFactory.initElements(driver, this);
    }

    public String cartQuantity () {
        wdWait.until(ExpectedConditions.elementToBeClickable(shoppingCart));
        return shoppingCart.getText();
    }

}

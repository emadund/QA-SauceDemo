package page;

import base.BaseSauce;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SauceDemoHome extends BaseSauce {
    @FindBy (css =("[placeholder=\"Username\"]"))
    WebElement username;
    @FindBy (css =("[placeholder=\"Password\"]"))
    WebElement password;
    @FindBy (id="login-button")
    WebElement loginButton;
    @FindBy (className="error-message-container error")
    WebElement errorBanner;
    public SauceDemoHome () {
        PageFactory.initElements(driver,this); //ERROR!!!! WHY?????
    }
public SauceDemoHome fillUsername (String x) {
        wdWait.until(ExpectedConditions.elementToBeClickable(username));
        username.clear();
        username.sendKeys(x);
        return this;

}
public SauceDemoHome fillPassword (String x) {
        wdWait.until(ExpectedConditions.elementToBeClickable(password));
        password.clear();
        password.sendKeys(x);
        return this;

}
public void clickLogin () {
        wdWait.until(ExpectedConditions.elementToBeClickable(loginButton));
        loginButton.click();
}
public boolean errorDisplaying () {
        wdWait.until(ExpectedConditions.visibilityOf(errorBanner));
        return errorBanner.isDisplayed();
}
public String errorText () {
        wdWait.until(ExpectedConditions.visibilityOf(errorBanner));
        return errorBanner.getText();
}



}

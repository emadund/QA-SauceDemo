package test;

import base.BaseSauce;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import page.SauceCart;
import page.SauceDemoHome;
import page.SauceInventory;

import java.util.Random;

public class SauceTest extends BaseSauce {
    private SauceDemoHome sauceDemoHome;
    private SauceInventory sauceInventory;
    private SauceCart sauceCart;
    private String[] testNames = {"standard_user","locked_out_user","problem_user","performance_glitch_user"};
    private final String testPassword = "secret_sauce";
    private Random rn = new Random();
    private int j = rn.nextInt(5)+1; // defining random number between 1 and 6;

    @Before
        public void initialTest () {
        sauceDemoHome = new SauceDemoHome();
        sauceInventory = new SauceInventory();
        sauceCart = new SauceCart();

        }

    @Test

    public void negativeTestCase1 () {
       sauceDemoHome.fillUsername(""+Math.random()*10)
                .fillPassword(testPassword)
                .clickLogin();
        Assert.assertTrue(sauceDemoHome.errorDisplaying());
        Assert.assertEquals("Epic sadface: Username and password do not match any user in this service",sauceDemoHome.errorText());
        // This is first general negative test case with wrong username
    }
    @Test
    public void negativeTestCase2 () {
        for (String x:testNames) {
        sauceDemoHome.fillUsername(x)
                .fillPassword(""+Math.random()*10)
                .clickLogin();
            Assert.assertTrue(sauceDemoHome.errorDisplaying());
            Assert.assertEquals("Epic sadface: Username and password do not match any user in this service",sauceDemoHome.errorText());}
            // 2nd general negative test case with wrong password

    }
    @Test
    public void negativeTestCase3 () {
        sauceDemoHome.clickLogin();
        Assert.assertTrue(sauceDemoHome.errorDisplaying());
        Assert.assertEquals("Epic sadface: Username is required",sauceDemoHome.errorText());
        // 3rd general negative test case with both fields empty
    }

    @Test
    public void positiveTestCase1 () {
        sauceDemoHome.fillUsername(testNames[0])
                .fillPassword(testPassword)
                .clickLogin();
        sauceInventory.clickRequestedItem(j);
        Assert.assertTrue(sauceInventory.basketDisplayed());
        Assert.assertEquals("1",sauceInventory.basketQuantity());
        // As requested in task, we picked up one Random item, put in cart and checked out if there is 1 chosen
        if (j==1) // In Case random number is 1, we avoid next random choice to be 0
        {
            sauceInventory.clickRequestedItemDetails(2);
            sauceInventory.addDetailedItem();
            Assert.assertEquals("2",sauceCart.cartQuantity());
        }
        else // Explained in previous comment
        { sauceInventory.clickRequestedItemDetails(j-1);
            sauceInventory.addDetailedItem();
            Assert.assertEquals("2",sauceCart.cartQuantity());}
    }



}
